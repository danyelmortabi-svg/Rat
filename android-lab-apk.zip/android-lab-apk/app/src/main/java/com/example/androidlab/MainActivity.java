package com.example.androidlab;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity {
  private EditText address;
  private WebView web;
  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    LinearLayout root = new LinearLayout(this);
    root.setOrientation(LinearLayout.VERTICAL);
    root.setPadding(18, 18, 18, 18);
    root.setBackgroundColor(Color.rgb(245,247,250));
    TextView title = new TextView(this);
    title.setText("Android Lab — Demo Client");
    title.setTextSize(22); title.setTextColor(Color.rgb(25,45,70));
    root.addView(title, new LinearLayout.LayoutParams(-1, -2));
    TextView note = new TextView(this);
    note.setText("Visible demo only. This app does not secretly control the device. Enter the address of your own lab panel.");
    note.setTextSize(14); note.setPadding(0,12,0,12);
    root.addView(note, new LinearLayout.LayoutParams(-1,-2));
    address = new EditText(this);
    address.setSingleLine(true);
    address.setText("http://127.0.0.1:3000");
    address.setHint("http://your-lab-server:3000");
    root.addView(address, new LinearLayout.LayoutParams(-1,-2));
    Button open = new Button(this); open.setText("Open lab panel");
    root.addView(open, new LinearLayout.LayoutParams(-1,-2));
    web = new WebView(this); web.setWebViewClient(new WebViewClient());
    web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setDomStorageEnabled(true);
    root.addView(web, new LinearLayout.LayoutParams(-1,0,1));
    open.setOnClickListener(v -> { String u=address.getText().toString().trim(); if(!u.startsWith("http://") && !u.startsWith("https://")) u="http://"+u; web.loadUrl(u); });
    setContentView(root);
  }
  @Override public void onBackPressed() { if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
